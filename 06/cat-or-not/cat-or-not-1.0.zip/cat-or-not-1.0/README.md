# Cat or Not
An Keras + Python image classifier that determines whether or not an image is of a cat.
